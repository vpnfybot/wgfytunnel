// Copyright 2014 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package intsets

// Backdoor for testing.
func (s *Sparse) Check() error { return s.check() }
